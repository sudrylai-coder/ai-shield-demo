// Adapter-independent policy core. No OpenClaw imports here.
// Input checks and tool decisions are plain functions so another system (browser, other agent host) could reuse them.
import path from "node:path";
import fs from "node:fs";

export function luhnOk(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
}

export function israeliIdOk(id) {
  if (!/^\d{9}$/.test(id)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    let n = (id.charCodeAt(i) - 48) * (i % 2 === 0 ? 1 : 2);
    if (n > 9) n -= 9;
    sum += n;
  }
  return sum % 10 === 0;
}

const INJECTION = [
  /ignore (all )?(the )?(previous|prior|above) (instructions|rules)/i,
  /disregard (your|the) (system|safety) (prompt|rules|instructions)/i,
  /reveal (your )?(system prompt|hidden instructions)/i,
];
// Rules adapted from Yossi's AI Shield spec (maatefet/IMPLEMENTATION.md @ a6a3bfa, DLP table + manipulations list).
const INJECTION_HE = [/התעלם (מכל|מה)\s*(ה)?(הוראות|הנחיות)/, /מצב מפתח/, /חשוף את (הנחיות|ההוראות) (המערכת|הסודיות)/];
const CLASS_LABELS = [/סודי ביותר/, /לשימוש פנימי בלבד/, /top secret/i, /internal use only/i, /\bconfidential\b.{0,20}\bdo not (share|distribute)\b/i];
const SECRET = [
  /\bsk-[A-Za-z0-9]{20,}\b/, /\bgithub_pat_[A-Za-z0-9_]{20,}\b/, /\bghp_[A-Za-z0-9]{30,}\b/,
  /\bAKIA[0-9A-Z]{16}\b/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
];

// Returns a list of safe category names (never the matched text).
export function inspectInput(text) {
  const found = new Set();
  const s = String(text ?? "");
  for (const m of s.matchAll(/(?<![\d])(?:\d[ -]?){13,19}(?![\d])/g)) {
    const d = m[0].replace(/[ -]/g, "");
    if (d.length >= 13 && d.length <= 19 && luhnOk(d)) found.add("credit_card");
  }
  for (const m of s.matchAll(/(?<![\d])\d{9}(?![\d])/g)) if (israeliIdOk(m[0])) found.add("israeli_id");
  if (SECRET.some((r) => r.test(s))) found.add("secret_or_key");
  if (/(?:[A-Za-z0-9+/]{80,}={0,2}|\b(?:[0-9a-fA-F]{2}){40,}\b)/.test(s)) found.add("suspicious_encoding");
  if (CLASS_LABELS.some((r) => r.test(s))) found.add("classification_label");
  if (INJECTION_HE.some((r) => r.test(s))) found.add("prompt_injection_phrase");
  if (INJECTION.some((r) => r.test(s))) found.add("prompt_injection_phrase");
  return [...found];
}

const FORBIDDEN_EXT = /\.(pem|key|pfx|p12|env|sql|bak|pst)$/i;
const FORBIDDEN_NAME = /(^|[\\/])(\.env(\..*)?|id_rsa|id_ed25519|credentials|config\.json)$/i;
const PRIVATE_MAIL = /@(gmail|yahoo|hotmail|outlook|walla)\.[a-z.]+$/i;
// Command guard adapted from Yossi's list: destructive SQL, privilege escalation, system commands.
const DANGEROUS_SHELL = [
  /\bdrop\s+(table|database)\b/i, /\btruncate\s+table\b/i, /\bdelete\s+from\s+\w+\s*(;|$)/i,
  /\bgrant\s+all\b/i, /\b(alter|create)\s+user\b/i, /net\s+localgroup\s+administrators/i, /usermod\s+-aG\s+sudo/i,
  /\bdel\s+\/f\b/i, /\bformat\s+[a-z]:/i, /\b(invoke-expression|iex)\b/i, /powershell(\.exe)?\s+-enc/i, /\.env\b/, /id_rsa/,
  /\brm\s+(-[a-zA-Z]*\s+)*\S/, /\bmkfs\b/, /\bdd\s+if=/, /\bchmod\s+-R\b/, /\bsudo\b/,
  /(curl|wget)[^|;&]*\|\s*(sh|bash)/, /\bnc\s+-e\b/, /\/etc\/(passwd|shadow)/, /\.ssh\//, /\bbase64\s+(-d|--decode)/,
];

// Canonicalize: resolve symlinks of the path, or of its deepest existing ancestor (for new files).
function canon(p) {
  let cur = path.resolve(p);
  const rest = [];
  for (;;) {
    try { const r = fs.realpathSync(cur); return path.join(r, ...rest.reverse()); }
    catch { const parent = path.dirname(cur); if (parent === cur) return path.resolve(p); rest.push(path.basename(cur)); cur = parent; }
  }
}
function insideRoot(p, root) {
  const realRoot = canon(root);
  const abs = canon(path.resolve(root, String(p)));
  return abs === realRoot || abs.startsWith(realRoot + path.sep);
}

// cfg: { workspaceRoot, allowTools[], approvalTools[] }
// Returns { decision: "allow"|"approval"|"deny", reason }
export function decideTool(toolName, params, cfg) {
  const root = path.resolve(cfg.workspaceRoot);
  const p = params ?? {};
  const pathArg = p.path ?? p.file ?? p.file_path ?? p.filePath;
  if (pathArg !== undefined && (FORBIDDEN_EXT.test(String(pathArg)) || FORBIDDEN_NAME.test(String(pathArg)))) {
    return { decision: "deny", reason: `forbidden file type for ${toolName} (keys, env, sql, backups)` };
  }
  const dest = p.to ?? p.recipient ?? p.email;
  if (dest !== undefined && PRIVATE_MAIL.test(String(dest))) {
    return { decision: "deny", reason: "personal email destination (approval path not enabled)" };
  }
  if (pathArg !== undefined && !insideRoot(pathArg, root)) {
    return { decision: "deny", reason: `path outside workspace for ${toolName}` };
  }
  if (toolName === "exec" || toolName === "bash") {
    const cmd = String(p.command ?? p.cmd ?? "");
    if (DANGEROUS_SHELL.some((r) => r.test(cmd))) return { decision: "deny", reason: "dangerous shell pattern" };
    if ((cfg.approvalTools ?? []).includes(toolName)) return { decision: "approval", reason: "shell command needs human approval" };
    return { decision: "deny", reason: "shell commands are blocked (approval path not enabled)" };
  }
  if ((cfg.allowTools ?? []).includes(toolName)) return { decision: "allow", reason: "tool on allowlist" };
  if ((cfg.approvalTools ?? []).includes(toolName)) return { decision: "approval", reason: `${toolName} needs human approval` };
  return { decision: "deny", reason: `tool ${toolName} not on allowlist (default deny)` };
}

// Risk tiers (Yossi's R.A.C.E levels, mapped to the tested OpenClaw tool names).
export const RISK_TIER = { read: 1, write: 2, edit: 2, apply_patch: 2, message: 2, exec: 3, bash: 3, process: 3 };

// Optional semantic layer. NOT a model: a pluggable async function. Hard denies above never go through it.
// classify(text) must resolve {risky:boolean} within timeoutMs. State is explicit:
//   "rules_ok" (checked by rules only), "classifier_ok", "classifier_block", "could_not_inspect".
export async function inspectWithClassifier(text, classify, { timeoutMs = 3000, required = false } = {}) {
  const cats = inspectInput(text);
  if (cats.length) return { state: "rules_block", categories: cats };
  if (!classify) return { state: "rules_ok", categories: [] };
  try {
    const r = await Promise.race([classify(text), new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), timeoutMs))]);
    return r && r.risky ? { state: "classifier_block", categories: ["semantic_risk"] } : { state: "classifier_ok", categories: [] };
  } catch {
    return required ? { state: "could_not_inspect", categories: ["classifier_unavailable"] } : { state: "rules_ok", categories: [], note: "classifier unavailable, rules only" };
  }
}
