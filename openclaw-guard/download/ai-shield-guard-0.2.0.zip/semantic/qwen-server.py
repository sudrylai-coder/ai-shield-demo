import os, torch, json, re
MODEL_DIR=os.environ.get("AI_SHIELD_MODEL_DIR", os.path.expanduser("~/.ai-shield/qwen3guard-0.6b"))
from http.server import BaseHTTPRequestHandler, HTTPServer
from transformers import AutoModelForCausalLM, AutoTokenizer
tok=AutoTokenizer.from_pretrained(MODEL_DIR, local_files_only=True)
m=AutoModelForCausalLM.from_pretrained(MODEL_DIR, local_files_only=True, trust_remote_code=False, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
def classify(text):
    ids=tok.apply_chat_template([{"role":"user","content":text}], add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
    with torch.no_grad(): out=m.generate(ids, max_new_tokens=24, do_sample=False)
    return tok.decode(out[0][ids.shape[1]:], skip_special_tokens=True).replace("\n"," ")
class H(BaseHTTPRequestHandler):
    def do_POST(self):
        t=json.loads(self.rfile.read(int(self.headers["content-length"]))).get("text","")[:4000]
        raw=classify(t); label=re.search(r"Safety: (Safe|Unsafe|Controversial)",raw)
        label=label.group(1) if label else "Unknown"
        body=json.dumps({"risky": label!="Safe", "label": label, "raw": raw}).encode()  # Unknown/Controversial/Unsafe all stop
        self.send_response(200); self.send_header("content-type","application/json"); self.end_headers(); self.wfile.write(body)
    def log_message(self,*a): pass
HTTPServer(("127.0.0.1",18998),H).serve_forever()
