#!/usr/bin/env bash
# OPTIONAL. Downloads ~1.5 GB model (Qwen/Qwen3Guard-Gen-0.6B, Apache-2.0) plus PyTorch CPU and transformers into ~/.ai-shield.
# Needs internet once. Needs python3 (3.10+), about 4 GB free disk and about 2 GB free RAM. Nothing is sent anywhere: text is classified locally.
set -euo pipefail
D="${AI_SHIELD_HOME:-$HOME/.ai-shield}"; M="$D/qwen3guard-0.6b"
EXPECT=4f3ce47ebd968cddb67de08d8764f8ede7c410a7d1fb9e08145a4c7a2f2e5c0f
echo "About to download ~1.5 GB model and Python packages into $D"; [ "${1:-}" = "--yes" ] || { echo "Re-run with --yes to confirm."; exit 1; }
mkdir -p "$D"; python3 -m venv "$D/venv"
"$D/venv/bin/pip" install -q torch --index-url https://download.pytorch.org/whl/cpu
"$D/venv/bin/pip" install -q transformers accelerate huggingface_hub
"$D/venv/bin/python" -c "from huggingface_hub import snapshot_download; snapshot_download('Qwen/Qwen3Guard-Gen-0.6B', local_dir='$M')"
GOT=$(sha256sum "$M/model.safetensors" | cut -d' ' -f1)
[ "$GOT" = "$EXPECT" ] || { echo "CHECKSUM MISMATCH ($GOT). Not using this model."; exit 1; }
echo "Model checksum OK."
echo "Start the local classifier:   AI_SHIELD_MODEL_DIR=$M $D/venv/bin/python $(cd "$(dirname "$0")" && pwd)/qwen-server.py"
echo "Then enable it:                bash $(cd "$(dirname "$0")" && pwd)/enable-semantic.sh"
