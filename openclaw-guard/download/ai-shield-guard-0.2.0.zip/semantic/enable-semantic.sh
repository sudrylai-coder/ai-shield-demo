#!/usr/bin/env bash
# Turns the local classifier on in the plugin config. "required": true means: if the classifier is not running, messages are STOPPED (not passed).
set -euo pipefail
CUR="$(openclaw config get plugins.entries.ai-shield-guard.config --json)"
NEW="$(printf '%s' "$CUR" | python3 -c "import sys,json;c=json.load(sys.stdin);c['semanticCheck']={'url':'http://127.0.0.1:18998/classify','timeoutMs':20000,'required':True};print(json.dumps(c))")"
openclaw config set plugins.entries.ai-shield-guard.config "$NEW" --strict-json
echo "Semantic check ON (required). If you stop the classifier server, messages will be blocked with 'could not run its required safety check'."
