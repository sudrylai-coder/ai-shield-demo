#!/usr/bin/env bash
# Removes the plugin and its config entry. Other config (including edits you made after install) is left as it is.
# The pre-install backup (openclaw.json.ai-shield-backup-*) is NOT restored automatically, to avoid overwriting later edits.
set -euo pipefail
openclaw plugins uninstall ai-shield-guard --force || true
openclaw config unset plugins.entries.ai-shield-guard || true
echo "Removed. Restart the OpenClaw gateway."
