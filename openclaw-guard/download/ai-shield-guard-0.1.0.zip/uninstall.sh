#!/usr/bin/env bash
set -euo pipefail
openclaw plugins uninstall ai-shield-guard --force || true
echo "Removed. Restart the OpenClaw gateway."
