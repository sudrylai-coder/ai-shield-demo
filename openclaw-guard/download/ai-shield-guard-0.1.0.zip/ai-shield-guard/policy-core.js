// Adapter-independent policy core. No OpenClaw imports here.
// Input checks and tool decisions are plain functions so another system (browser, other agent host) could reuse them.
import path from "node:path";
import fs from "node:fs";

export function luhnOk(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
}

export function israeliIdOk(id) {
  if (!/^\d{9}$/.test(id)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    let n = (id.charCodeAt(i) - 48) * (i % 2 === 0 ? 1 : 2);
    if (n > 9) n -= 9;
    sum += n;
  }
  return sum % 10 === 0;
}

const INJECTION = [
  /ignore (all )?(the )?(previous|prior|above) (instructions|rules)/i,
  /disregard (your|the) (system|safety) (prompt|rules|instructions)/i,
  /reveal (your )?(system prompt|hidden instructions)/i,
];
const SECRET = [
  /\bsk-[A-Za-z0-9]{20,}\b/, /\bgithub_pat_[A-Za-z0-9_]{20,}\b/, /\bghp_[A-Za-z0-9]{30,}\b/,
  /\bAKIA[0-9A-Z]{16}\b/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
];

// Returns a list of safe category names (never the matched text).
export function inspectInput(text) {
  const found = new Set();
  const s = String(text ?? "");
  for (const m of s.matchAll(/(?<![\d])(?:\d[ -]?){13,19}(?![\d])/g)) {
    const d = m[0].replace(/[ -]/g, "");
    if (d.length >= 13 && d.length <= 19 && luhnOk(d)) found.add("credit_card");
  }
  for (const m of s.matchAll(/(?<![\d])\d{9}(?![\d])/g)) if (israeliIdOk(m[0])) found.add("israeli_id");
  if (SECRET.some((r) => r.test(s))) found.add("secret_or_key");
  if (INJECTION.some((r) => r.test(s))) found.add("prompt_injection_phrase");
  return [...found];
}

const DANGEROUS_SHELL = [
  /\brm\s+(-[a-zA-Z]*\s+)*\S/, /\bmkfs\b/, /\bdd\s+if=/, /\bchmod\s+-R\b/, /\bsudo\b/,
  /(curl|wget)[^|;&]*\|\s*(sh|bash)/, /\bnc\s+-e\b/, /\/etc\/(passwd|shadow)/, /\.ssh\//, /\bbase64\s+(-d|--decode)/,
];

// Canonicalize: resolve symlinks of the path, or of its deepest existing ancestor (for new files).
function canon(p) {
  let cur = path.resolve(p);
  const rest = [];
  for (;;) {
    try { const r = fs.realpathSync(cur); return path.join(r, ...rest.reverse()); }
    catch { const parent = path.dirname(cur); if (parent === cur) return path.resolve(p); rest.push(path.basename(cur)); cur = parent; }
  }
}
function insideRoot(p, root) {
  const realRoot = canon(root);
  const abs = canon(path.resolve(root, String(p)));
  return abs === realRoot || abs.startsWith(realRoot + path.sep);
}

// cfg: { workspaceRoot, allowTools[], approvalTools[] }
// Returns { decision: "allow"|"approval"|"deny", reason }
export function decideTool(toolName, params, cfg) {
  const root = path.resolve(cfg.workspaceRoot);
  const p = params ?? {};
  const pathArg = p.path ?? p.file ?? p.file_path ?? p.filePath;
  if (pathArg !== undefined && !insideRoot(pathArg, root)) {
    return { decision: "deny", reason: `path outside workspace for ${toolName}` };
  }
  if (toolName === "exec" || toolName === "bash") {
    const cmd = String(p.command ?? p.cmd ?? "");
    if (DANGEROUS_SHELL.some((r) => r.test(cmd))) return { decision: "deny", reason: "dangerous shell pattern" };
    if ((cfg.approvalTools ?? []).includes(toolName)) return { decision: "approval", reason: "shell command needs human approval" };
    return { decision: "deny", reason: "shell commands are blocked (approval path not enabled)" };
  }
  if ((cfg.allowTools ?? []).includes(toolName)) return { decision: "allow", reason: "tool on allowlist" };
  if ((cfg.approvalTools ?? []).includes(toolName)) return { decision: "approval", reason: `${toolName} needs human approval` };
  return { decision: "deny", reason: `tool ${toolName} not on allowlist (default deny)` };
}
