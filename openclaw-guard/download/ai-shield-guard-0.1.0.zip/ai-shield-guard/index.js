import fs from "node:fs";
import path from "node:path";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { inspectInput, decideTool } from "./policy-core.js";

export default definePluginEntry({
  id: "ai-shield-guard",
  name: "AI Shield Guard (prototype)",
  description: "Check input before the model and tool calls before they run.",
  register(api) {
    const cfg = {
      workspaceRoot: api.pluginConfig?.workspaceRoot ?? process.cwd(),
      auditFile: api.pluginConfig?.auditFile ?? path.join(process.cwd(), "ai-shield-audit.jsonl"),
      approvalTimeoutMs: api.pluginConfig?.approvalTimeoutMs ?? 60000,
      allowTools: api.pluginConfig?.allowTools ?? ["read"],
      approvalTools: api.pluginConfig?.approvalTools ?? [],
    };
    const audit = (rec) => {
      try { fs.appendFileSync(cfg.auditFile, JSON.stringify({ ts: new Date().toISOString(), ...rec }) + "\n"); } catch {}
    };

    api.on("before_agent_run", (event) => {
      const found = inspectInput(event.prompt);
      if (found.length === 0) { audit({ hook: "before_agent_run", outcome: "pass" }); return { outcome: "pass" }; }
      audit({ hook: "before_agent_run", outcome: "block", categories: found });
      return {
        outcome: "block",
        reason: `ai-shield: ${found.join(",")}`,
        message: "AI Shield blocked this message before it reached the model (sensitive data or an unsafe instruction was detected). Remove it and try again.",
      };
    });

    api.on("before_tool_call", (event) => {
      const d = decideTool(event.toolName, event.params, cfg);
      audit({ hook: "before_tool_call", tool: event.toolName, decision: d.decision, reason: d.reason });
      if (d.decision === "deny") return { block: true, blockReason: `AI Shield: ${d.reason}` };
      if (d.decision === "approval") {
        return {
          requireApproval: {
            title: `AI Shield: approve ${event.toolName}?`,
            description: d.reason,
            severity: "warning",
            timeoutMs: cfg.approvalTimeoutMs,
            allowedDecisions: ["allow-once", "deny"],
            onResolution: (decision) => audit({ hook: "approval_resolution", tool: event.toolName, decision }),
          },
        };
      }
      return undefined;
    });
  },
});
