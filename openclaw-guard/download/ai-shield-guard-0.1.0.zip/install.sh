#!/usr/bin/env bash
# AI Shield Guard (prototype) installer for OpenClaw 2026.11.x. Plain shell script: not signed, not a native installer.
set -euo pipefail
command -v openclaw >/dev/null || { echo "OpenClaw not found in PATH. Install OpenClaw first (needs Node 24.16+)."; exit 1; }
DIR="$(cd "$(dirname "$0")" && pwd)/ai-shield-guard"
WS="${AI_SHIELD_WORKSPACE:-$HOME/.openclaw/workspace}"
AUDIT="${AI_SHIELD_AUDIT:-$HOME/.openclaw/ai-shield-audit.jsonl}"
echo "OpenClaw: $(openclaw --version)"
echo "Guarded workspace: $WS"
mkdir -p "$WS"
CFG="$(openclaw config file | tail -1)"
if [ -f "$CFG" ]; then cp "$CFG" "$CFG.ai-shield-backup-$(date +%s)"; echo "Config backup saved next to $CFG"; fi
echo "This plugin reads conversation text and sees tool calls (that is how it checks them). Running this script means you accept that."
openclaw plugins install "$DIR" --force --accept-capabilities
openclaw config set plugins.entries.ai-shield-guard.enabled true --strict-json
openclaw config set plugins.entries.ai-shield-guard.hooks.allowConversationAccess true --strict-json
openclaw config set plugins.entries.ai-shield-guard.config "{\"workspaceRoot\":\"$WS\",\"auditFile\":\"$AUDIT\",\"allowTools\":[\"read\"],\"approvalTools\":[]}" --strict-json
echo "Installed. Restart the OpenClaw gateway to apply. Audit log: $AUDIT"
openclaw plugins inspect ai-shield-guard --json | head -c 600; echo
