(() => {
  const textOf = (el) => !el ? "" : (el.value !== undefined ? el.value : el.innerText || el.textContent || "");
  const isBox = (el) => el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && /^(text|search|)$/.test(el.type)) || el.isContentEditable);
  const boxFor = (el) => {
    if (isBox(el)) return el;
    const root = (el && el.closest && el.closest("form")) || document;
    return [...root.querySelectorAll("textarea,input[type=text],input:not([type]),[contenteditable=''],[contenteditable='true']")].find((x) => textOf(x).trim()) || null;
  };
  const setBadge = (state) => {
    let g = document.getElementById("ai-shield-badge");
    if (!g) { g = document.createElement("div"); g.id = "ai-shield-badge"; g.style.cssText = "position:fixed;bottom:8px;left:8px;z-index:2147483646;background:#0e6b5c;color:#fff;padding:4px 10px;border-radius:999px;font:12px system-ui;pointer-events:none"; document.documentElement.appendChild(g); }
    const ok = state === "on" && typeof self.AIShieldInspect === "function";
    g.textContent = ok ? "AI Shield: ON (duck.ai)" : "AI Shield: ERROR, sending blocked";
    g.style.background = ok ? "#0e6b5c" : "#b42318";
    document.documentElement.setAttribute("data-ai-shield-status", ok ? "on" : "error");
  };
  const banner = (cats) => {
    let b = document.getElementById("ai-shield-banner");
    if (!b) { b = document.createElement("div"); b.id = "ai-shield-banner"; b.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#0e6b5c;color:#fff;padding:10px;font:14px system-ui;text-align:center"; (document.documentElement).appendChild(b); }
    b.textContent = "AI Shield blocked sending: " + cats.join(", ") + ". Remove it and try again.";
    document.documentElement.setAttribute("data-ai-shield-blocked", cats.join(","));
  };
  const failClosed = (ev) => {
    ev.preventDefault(); ev.stopImmediatePropagation();
    banner(["guard error"]);
    document.getElementById("ai-shield-banner").textContent = "AI Shield could not check this message, so it was NOT sent. Reload the page or disable the extension.";
    document.documentElement.setAttribute("data-ai-shield-blocked", "guard_error");
    setBadge("error");
  };
  const check = (box, ev) => {
    let cats;
    try { cats = self.AIShieldInspect(textOf(box)); if (!Array.isArray(cats)) throw new Error("bad"); } catch (e) { failClosed(ev); return true; }
    if (cats.length) { ev.preventDefault(); ev.stopImmediatePropagation(); banner(cats); return true; }
    return false;
  };
  const initBadge = () => setBadge("on");
  if (document.documentElement) initBadge(); else addEventListener("DOMContentLoaded", initBadge);
  setInterval(() => { if (!document.getElementById("ai-shield-badge")) initBadge(); }, 2000);
  addEventListener("keydown", (ev) => {
    if (ev.key !== "Enter" || ev.shiftKey || ev.isComposing) return;
    const box = isBox(ev.target) ? ev.target : null; if (box) check(box, ev);
  }, true);
  addEventListener("click", (ev) => {
    const b = ev.target.closest && ev.target.closest("button,[role=button],input[type=submit]"); if (!b) return;
    if (b.type === "submit" || /send|שלח|submit/i.test((b.getAttribute("aria-label") || "") + " " + (b.getAttribute("data-testid") || "") + " " + b.innerText)) {
      const box = boxFor(b); if (box) check(box, ev);
    }
  }, true);
  addEventListener("submit", (ev) => { const box = boxFor(ev.target); if (box) check(box, ev); }, true);
})();
