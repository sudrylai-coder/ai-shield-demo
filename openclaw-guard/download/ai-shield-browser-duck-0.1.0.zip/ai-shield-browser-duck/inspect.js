// Generated from policy-core.js (input checks only).
function luhnOk(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
}

function israeliIdOk(id) {
  if (!/^\d{9}$/.test(id)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    let n = (id.charCodeAt(i) - 48) * (i % 2 === 0 ? 1 : 2);
    if (n > 9) n -= 9;
    sum += n;
  }
  return sum % 10 === 0;
}

const INJECTION = [
  /ignore (all )?(the )?(previous|prior|above) (instructions|rules)/i,
  /disregard (your|the) (system|safety) (prompt|rules|instructions)/i,
  /reveal (your )?(system prompt|hidden instructions)/i,
];
const SECRET = [
  /\bsk-[A-Za-z0-9]{20,}\b/, /\bgithub_pat_[A-Za-z0-9_]{20,}\b/, /\bghp_[A-Za-z0-9]{30,}\b/,
  /\bAKIA[0-9A-Z]{16}\b/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
];

// Returns a list of safe category names (never the matched text).
function inspectInput(text) {
  const found = new Set();
  const s = String(text ?? "");
  for (const m of s.matchAll(/(?<![\d])(?:\d[ -]?){13,19}(?![\d])/g)) {
    const d = m[0].replace(/[ -]/g, "");
    if (d.length >= 13 && d.length <= 19 && luhnOk(d)) found.add("credit_card");
  }
  for (const m of s.matchAll(/(?<![\d])\d{9}(?![\d])/g)) if (israeliIdOk(m[0])) found.add("israeli_id");
  if (SECRET.some((r) => r.test(s))) found.add("secret_or_key");
  if (INJECTION.some((r) => r.test(s))) found.add("prompt_injection_phrase");
  return [...found];
}


self.AIShieldInspect=inspectInput;
