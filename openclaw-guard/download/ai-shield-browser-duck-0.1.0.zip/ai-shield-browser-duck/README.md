# AI Shield browser prototype 0.1.0 (duck.ai only)
Unpacked Chrome extension. Not one-click, not signed, not in the Chrome Web Store.
Install: unzip, open chrome://extensions, enable Developer mode, "Load unpacked", pick this folder.
What it does: on https://duck.ai/* only, it stops Enter / send-click / form submit when the text contains a card number (Luhn), Israeli ID, secret/key, classification label, long base64/hex or an injection phrase (EN/HE). It shows a banner. It does not log or send any text.
Tested (real Chrome 157, synthetic text, no terms accepted, no real prompt sent): card + Enter blocked, card + Send button blocked, clean text passes, also after clicking New chat. Control without the extension (and after New chat): the page accepts the same card text. Evidence is DOM-level (no message bubble, status attributes); duck.ai shows a first-use terms card, so no network attempt could be shown. Status: a badge bottom-left shows "AI Shield: ON (duck.ai)"; no badge means the extension is off or the page is not duck.ai. Failure: if the check code throws, sending is blocked and the badge turns red (tested with deliberately broken code).
Not tested: other sites, uninstalling mid-session. Not supported: any other site.
Limits: UI-level guard only. Page scripts, pasted-in files, other browsers, direct network calls and disabling the extension bypass it. Not a sandbox.
