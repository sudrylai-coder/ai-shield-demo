# AI Shield browser prototype 0.2.0 (duck.ai only)
Unpacked Chrome extension. Not one-click, not signed, not in the Chrome Web Store. Linux-tested helper only.
Install: unzip, chrome://extensions, Developer mode, Load unpacked, pick this folder.

## Modes (edit config.js, then reload the extension)
- "rules" (default): hard rules only (card/Luhn, Israeli ID, secrets, classification labels, long base64/hex, injection phrases EN/HE). No model, no helper. Badge: "ON, rules only".
- "rules+model": hard rules first, then a REQUIRED check by a local model through the helper. If the helper is down, slow (25 s), unpaired or answers anything but a valid yes/no, sending is BLOCKED and the page says why (red badge). The model can only block more, never allow what a rule blocked.
  Flow: Enter -> rules -> model -> banner "checked, press Enter/Send again within 60 s". The clearance is for that exact text in that exact composer and chat URL, works once, and rules run again on the second press. Editing, changing chat or a duplicate press needs a new check. The extension never presses Enter or clicks Send for you.

## Optional local helper (not installed by this zip, model not downloaded automatically)
1. Set up the model and Python packages yourself with the setup-semantic.sh from the OpenClaw 0.2.0 zip (about 1.5 GB, Qwen3Guard-Gen-0.6B, Apache-2.0, checksum-checked), or any equivalent venv with torch + transformers.
2. Run helper/shield-helper.py with that venv's python. First start creates ~/.ai-shield/helper-token (mode 0600).
3. Copy the token into config.js (token field) yourself. The token is only in that file and the helper's file: never in a URL, the page, or chat. The page script cannot read it (only the extension background uses it).
Helper protections (tested): binds 127.0.0.1 only; POST-only; needs Origin chrome-extension://... AND the token AND Host 127.0.0.1:18998; no CORS headers, preflight refused; body max 4000 bytes; 5 s read timeout; one check at a time (429 otherwise); no config endpoint; no prompt storage or logging.
What that does NOT protect: the Origin header is set by the caller and proves nothing by itself. The token file is readable by any process running as the same user, so same-user malware can call the helper (it would only get yes/no classifications, but it could also read the token). It protects against web pages, other local users and other origins, not against malware on your account.

## Tested (real Chrome 157, synthetic text, throwaway profile, all non-GET requests failed by the test harness, terms never knowingly accepted)
Rules-only and rules+model modes, model block, rules block, single-use/edit/URL-change clearance, helper down, wrong token, empty/garbage/wrong-type/hung helper (all blocked), after New chat. Evidence is DOM-level; duck.ai shows a terms card on first send so no network attempt could be shown for clean text.
Not tested: other sites, Windows/macOS, uninstall mid-session, latency on other machines (lab, 1 CPU: about 5 to 7 s from Enter to verdict).
Limits: UI-level guard only. Page scripts, pasted files, other browsers, direct network calls and disabling the extension bypass it. Not a sandbox. duck.ai only.
