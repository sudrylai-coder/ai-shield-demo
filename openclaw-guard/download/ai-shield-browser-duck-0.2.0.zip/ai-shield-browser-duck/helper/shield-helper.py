#!/usr/bin/env python3
"""AI Shield local helper (optional). Loopback only. Classifies text with a LOCAL model; nothing leaves the machine.
Protections: binds 127.0.0.1 only; every request needs a pairing token (X-Shield-Token) AND an Origin of chrome-extension://...;
Host header must be 127.0.0.1:PORT (blocks DNS rebinding); no CORS headers are ever sent, OPTIONS is refused; body max 4000 bytes,
read timeout 5 s, one classification at a time (others get 429). Text is never written to disk or logged. Stateless: it cannot be configured over HTTP."""
import os, sys, json, re, secrets, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
PORT = int(os.environ.get("AI_SHIELD_PORT", "18998"))
HOME = os.environ.get("AI_SHIELD_HOME", os.path.expanduser("~/.ai-shield"))
MODEL_DIR = os.environ.get("AI_SHIELD_MODEL_DIR", os.path.join(HOME, "qwen3guard-0.6b"))
TOKEN_FILE = os.path.join(HOME, "helper-token")
MAX_BODY = 4000
os.makedirs(HOME, exist_ok=True)
if not os.path.exists(TOKEN_FILE):
    fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f: f.write(secrets.token_urlsafe(24))
TOKEN = open(TOKEN_FILE).read().strip()
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
tok = AutoTokenizer.from_pretrained(MODEL_DIR, local_files_only=True)
m = AutoModelForCausalLM.from_pretrained(MODEL_DIR, local_files_only=True, trust_remote_code=False, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
busy = threading.Semaphore(1)
def classify(text):
    ids = tok.apply_chat_template([{"role": "user", "content": text}], add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
    with torch.no_grad(): out = m.generate(ids, max_new_tokens=24, do_sample=False)
    return tok.decode(out[0][ids.shape[1]:], skip_special_tokens=True).replace("\n", " ")
class H(BaseHTTPRequestHandler):
    timeout = 5
    def _send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("content-type", "application/json"); self.send_header("content-length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _auth(self):
        if self.headers.get("Host", "") != f"127.0.0.1:{PORT}": self._send(403, {"error": "host"}); return False
        if not (self.headers.get("Origin", "").startswith("chrome-extension://")): self._send(403, {"error": "origin"}); return False
        if not secrets.compare_digest(self.headers.get("X-Shield-Token", ""), TOKEN): self._send(401, {"error": "token"}); return False
        return True
    def do_OPTIONS(self): self._send(403, {"error": "no cors"})
    def do_GET(self): self._send(405, {"error": "post only"})  # browsers may omit Origin on GET, so every endpoint is POST
    def do_POST(self):
        if not self._auth(): return
        if self.path == "/health": return self._send(200, {"ok": True, "model": "Qwen3Guard-Gen-0.6B"})
        if self.path != "/check": return self._send(404, {"error": "nf"})
        try: n = int(self.headers.get("content-length", "-1"))
        except ValueError: n = -1
        if n < 0 or n > MAX_BODY: return self._send(413, {"error": "too large"})
        try: text = json.loads(self.rfile.read(n)).get("text", "")
        except Exception: return self._send(400, {"error": "bad"})
        if not isinstance(text, str): return self._send(400, {"error": "bad"})
        if not busy.acquire(blocking=False): return self._send(429, {"error": "busy"})
        try:
            raw = classify(text); mt = re.search(r"Safety: (Safe|Unsafe|Controversial)", raw)
            label = mt.group(1) if mt else "Unknown"
            self._send(200, {"risky": label != "Safe", "label": label})  # Unknown/Controversial/Unsafe all stop
        finally: busy.release()
    def log_message(self, *a): pass
print(f"AI Shield helper on 127.0.0.1:{PORT}. Pairing token is in {TOKEN_FILE} (paste into the extension's config.js).", flush=True)
ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
