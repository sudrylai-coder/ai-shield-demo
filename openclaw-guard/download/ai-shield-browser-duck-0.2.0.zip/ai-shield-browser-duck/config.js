// mode: "rules" (default, rules only, no model) or "rules+model" (requires the local helper; if it is unavailable, sending is BLOCKED).
self.AI_SHIELD_CONFIG = { mode: "rules", port: 18998, token: "" };
