importScripts("config.js");
const C = self.AI_SHIELD_CONFIG;
const base = `http://127.0.0.1:${C.port}`;
async function call(path, body) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 25000);
  try {
    const r = await fetch(base + path, { method: "POST", headers: { "X-Shield-Token": C.token, "content-type": "application/json" }, body: JSON.stringify(body || {}), signal: ctl.signal });
    if (!r.ok) return { error: "helper_http_" + r.status };
    return await r.json();
  } catch (e) { return { error: "helper_unreachable" }; } finally { clearTimeout(t); }
}
chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.t === "mode") { send({ mode: C.mode }); return; }
  if (msg.t === "health") { call("/health").then(send); return true; }
  if (msg.t === "check") { call("/check", { text: String(msg.text).slice(0, 4000) }).then(send); return true; }
});
