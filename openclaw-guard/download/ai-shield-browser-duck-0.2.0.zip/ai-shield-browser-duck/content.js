(() => {
  let MODE = null, approved = null, pending = false, modelOk = null, lastUrl = location.href;
  const clearApproval = () => { approved = null; };
  const textOf = (el) => !el ? "" : (el.value !== undefined ? el.value : el.innerText || el.textContent || "");
  const isBox = (el) => el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && /^(text|search|)$/.test(el.type)) || el.isContentEditable);
  const boxFor = (el) => {
    if (isBox(el)) return el;
    const root = (el && el.closest && el.closest("form")) || document;
    return [...root.querySelectorAll("textarea,input[type=text],input:not([type]),[contenteditable=''],[contenteditable='true']")].find((x) => textOf(x).trim()) || null;
  };
  const root = () => document.documentElement;
  const setBadge = (state) => {
    let g = document.getElementById("ai-shield-badge");
    if (!g) { if (!root()) return; g = document.createElement("div"); g.id = "ai-shield-badge"; g.style.cssText = "position:fixed;bottom:8px;left:8px;z-index:2147483646;color:#fff;padding:4px 10px;border-radius:999px;font:12px system-ui;pointer-events:none"; root().appendChild(g); }
    const ruleOk = typeof self.AIShieldInspect === "function";
    let txt, col;
    if (!ruleOk || state === "error") { txt = "AI Shield: ERROR, sending blocked"; col = "#b42318"; state = "error"; }
    else if (state === "checking") { txt = "AI Shield: checking with local model..."; col = "#b54708"; }
    else if (MODE === "rules") { txt = "AI Shield: ON, rules only (duck.ai)"; col = "#0e6b5c"; state = "rules"; }
    else if (modelOk === false) { txt = "AI Shield: required local model NOT available, sending blocked"; col = "#b42318"; state = "model_down"; }
    else if (modelOk === true) { txt = "AI Shield: ON, rules + local model (duck.ai)"; col = "#0e6b5c"; state = "rules_model"; }
    else { txt = "AI Shield: starting..."; col = "#b54708"; state = "starting"; }
    g.textContent = txt; g.style.background = col; root().setAttribute("data-ai-shield-status", state);
  };
  const banner = (msg, flag) => {
    let b = document.getElementById("ai-shield-banner");
    if (!b) { b = document.createElement("div"); b.id = "ai-shield-banner"; b.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#0e6b5c;color:#fff;padding:10px;font:14px system-ui;text-align:center"; root().appendChild(b); }
    b.textContent = msg; root().setAttribute("data-ai-shield-blocked", flag);
  };
  const stop = (ev) => { ev.preventDefault(); ev.stopImmediatePropagation(); };
  const failClosed = (ev) => { stop(ev); banner("AI Shield could not check this message, so it was NOT sent. Reload the page or disable the extension.", "guard_error"); setBadge("error"); };
  const ask = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? { error: "extension_unreachable" } : (r || { error: "no_response" }))); } catch (e) { res({ error: "extension_unreachable" }); } });
  const check = (box, ev) => {
    try {
      const text = textOf(box);
      const cats = self.AIShieldInspect(text);
      if (!Array.isArray(cats)) throw new Error("bad");
      if (cats.length) { stop(ev); banner("AI Shield blocked sending: " + cats.join(", ") + ". Remove it and try again.", cats.join(",")); return true; }
      if (MODE === "rules") return false;
      if (MODE !== "rules+model") { stop(ev); banner("AI Shield is starting or misconfigured, so the message was NOT sent. Try again.", "starting"); return true; }
      if (approved && approved.box === box && approved.text === text && approved.url === location.href && Date.now() < approved.exp) { approved = null; return false; }
      approved = null;
      stop(ev);
      if (pending) return true;
      if (text.length > 4000) { banner("AI Shield blocked sending: the message is longer than 4000 characters, so the required local model check cannot cover it.", "model_too_long"); return true; }
      pending = true; setBadge("checking");
      const startUrl = location.href;
      ask({ t: "check", text }).then((res) => {
        pending = false;
        if (startUrl !== location.href || textOf(box) !== text) { banner("AI Shield: the message or chat changed while it was being checked, so nothing was approved. Press Enter again to re-check.", "recheck_needed"); return; }
        if (!res.error && typeof res.risky !== "boolean") res = { error: "bad_response" };
        if (res.error) { modelOk = false; banner("AI Shield: the required local model check is unavailable (" + res.error + "), so the message was NOT sent. Start the helper or switch to rules-only mode.", "model_unavailable"); setBadge(); return; }
        modelOk = true; setBadge();
        if (res.risky) { banner("AI Shield blocked sending: the local model flagged this message (" + String(res.label).slice(0, 20) + ").", "model_risky"); return; }
        approved = { text, box, url: location.href, exp: Date.now() + 60000 }; banner("AI Shield: the local model checked this message and found nothing. Press Enter / Send again within 60 seconds to send it.", "model_ok"); 
      });
      return true;
    } catch (e) { failClosed(ev); return true; }
  };
  ask({ t: "mode" }).then((r) => { MODE = r.mode || null; setBadge(); refreshHealth(); });
  const refreshHealth = () => { if (MODE !== "rules+model") return; ask({ t: "health" }).then((r) => { modelOk = !!(r && r.ok); setBadge(); }); };
  setInterval(() => { if (location.href !== lastUrl) { lastUrl = location.href; clearApproval(); } if (!document.getElementById("ai-shield-badge")) setBadge(); refreshHealth(); }, 5000);
  setBadge();
  addEventListener("keydown", (ev) => {
    if (ev.key !== "Enter" || ev.shiftKey || ev.isComposing) return;
    const box = isBox(ev.target) ? ev.target : null; if (box) check(box, ev);
  }, true);
  addEventListener("click", (ev) => {
    const b = ev.target.closest && ev.target.closest("button,[role=button],input[type=submit]"); if (!b) return;
    if (b.type === "submit" || /send|שלח|submit|ask/i.test((b.getAttribute("aria-label") || "") + " " + (b.getAttribute("data-testid") || "") + " " + b.innerText)) {
      const box = boxFor(b); if (box) check(box, ev);
    }
  }, true);
  addEventListener("submit", (ev) => { const box = boxFor(ev.target); if (box) check(box, ev); }, true);
})();
